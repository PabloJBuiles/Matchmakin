
const params = new URLSearchParams(window.location.search);

console.log(params);
if(!params.has("username")){
    window.location = "index.html";
    throw new Error("Se requiere el username");
}

let username = params.get("username");
//http://localhost:3000?username=manolo
const socket = io(window.location.host+"?username="+username);

document.getElementById("btnFindMatch").onclick= ()=>{
    socket.emit("findMatch");
}

socket.on("welcome",(data)=>{
    console.log(data.message);
})

socket.on("userConnected",(data)=>{
    console.log(data);
    console.log(data.username+" se ha conectado");
})
